// src/services/firestoreService.ts - COMPLETE VERSION WITH NPC MANAGEMENT

import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  onSnapshot,
  serverTimestamp,
  arrayUnion,
  deleteField,
  collection,
  getDocs,
  deleteDoc,
  query,
  where,
  orderBy
} from 'firebase/firestore';
import { db } from './firebase';
import type {
  Character,
  CharacterDoc,
  BattleSession,
  BattleSessionDoc,
  BattleToken,
  Position,
  CombatAction,
  InitiativeEntry,
  GMCombatAction, // Import from types file
  ActiveBuff, // NEW: Import for buff/debuff tracking  
  VanishedEnemy,
  CharacterCombatState
} from '../types';
import { CombatStateHelpers } from '../types/character'; // NEW IMPORT
import { StatusEffectService } from './statusEffectService';
import type { BattleMapPreset, PresetSaveData } from '../types';
export class FirestoreService {
  // ========== ENHANCED RESET METHOD WITH SAMPLE DATA INITIALIZATION ==========

  static async createDefaultInitiativeOrder(sessionId: string): Promise<void> {
    console.log('⚡ Creating default initiative order...');
    
    const defaultInitiativeOrder: InitiativeEntry[] = [
      {
        id: 'maelle',
        characterId: 'maelle',
        name: 'Maelle',
        initiative: 15, // High initiative for the fencer
        type: 'player',
        hasActed: false
      },
      {
        id: 'lune',
        characterId: 'lune', 
        name: 'Lune',
        initiative: 13, // Scholar with good reflexes
        type: 'player',
        hasActed: false
      },
      {
        id: 'sciel',
        characterId: 'sciel',
        name: 'Sciel', 
        initiative: 12, // Mystic with decent initiative
        type: 'player',
        hasActed: false
      },
      {
        id: 'gustave',
        characterId: 'gustave',
        name: 'Gustave',
        initiative: 10, // Engineer goes last typically
        type: 'player',
        hasActed: false
      }
    ];

    try {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        'combatState.initiativeOrder': defaultInitiativeOrder,
        'combatState.turnOrder': defaultInitiativeOrder.map(entry => entry.id),
        updatedAt: serverTimestamp()
      });
      
      console.log('✅ Default initiative order created successfully');
    } catch (error) {
      console.error('❌ Failed to create default initiative order:', error);
      throw error;
    }
  }

  static async createPendingAction(sessionId: string, action: any): Promise<void> {
    const sessionRef = doc(db, 'sessions', sessionId);
    await updateDoc(sessionRef, {
      pendingAction: action,
      lastUpdated: serverTimestamp()
    });
  }


 static async resetBattleSession(sessionId: string) {
  console.log('🔄 Starting complete battle session reset with tokens and initiative...');
  
  try {
    const session = await this.getBattleSession(sessionId);
    if (!session) {
      throw new Error('Session not found');
    }

    console.log('💰 Preserving inventory and gold data...');
    
    // 1. Save current inventory and gold for all characters BEFORE reset
    const characterIds = ['maelle', 'gustave', 'lune', 'sciel'];
    const preservedData: Record<string, { 
      inventory: any[], 
      gold: number,
      combatState: CharacterCombatState 
    }> = {};
    
    for (const characterId of characterIds) {
      const character = await this.getCharacter(characterId);
      
      if (character) {
        preservedData[characterId] = {
          inventory: character.inventory || [],
          gold: character.gold ?? 0,
          combatState: character.combatState || CombatStateHelpers.createDefaultCombatState()
        };
        console.log(`📦 Preserved ${characterId}: ${character.inventory?.length || 0} items, ${character.gold || 0} gold, combat state`);
      }
    }

    console.log('🗑️ Clearing battle session...');

    // 2. Clear the session completely first
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      tokens: {}, // This will be replaced with default player tokens
      combatState: {
        isActive: false,
        currentTurn: '',
        turnOrder: [],
        round: 1,
        phase: 'setup',
        initiativeOrder: [], // This will be replaced with default player initiative
      },
      pendingActions: [],
      enemyData: {},
      stormState: {
        isActive: false,
        currentTurn: 0,
        totalTurns: 0,
        pendingRolls: [],
      },
      updatedAt: serverTimestamp(),
    });

    console.log('📊 Reinitializing sample data...');

    // 3. Reinitialize sample data (this will overwrite characters)
    await this.initializeSampleData();

    // 4. CREATE DEFAULT PLAYER TOKENS (NEW!)
    console.log('🎭 Creating default player tokens on battle map...');
    await this.createDefaultPlayerTokens(sessionId);

    // 5. CREATE DEFAULT INITIATIVE ORDER (NEW!)
    console.log('⚡ Setting up default initiative order...');
    await this.createDefaultInitiativeOrder(sessionId);

    console.log('🔄 Restoring inventory, gold, and resetting combat state...');

    // 6. Restore inventory/gold and reset combat state for new battle
    for (const characterId of characterIds) {
      if (preservedData[characterId]) {
        const preserved = preservedData[characterId];
        
        // Reset combat state for new battle
        const newCombatState = CombatStateHelpers.resetForNewBattle(preserved.combatState);
        
        const characterRef = doc(db, 'characters', characterId);
        await updateDoc(characterRef, {
          inventory: preserved.inventory,
          gold: preserved.gold,
          combatState: {
            ...newCombatState,
            lastUpdated: serverTimestamp(),
            lastSyncedAt: serverTimestamp()
          },
          updatedAt: serverTimestamp(),
        });
        
        console.log(`✅ Restored and reset ${characterId}: ${preserved.inventory.length} items, ${preserved.gold} gold, fresh combat state`);
      }
    }

    console.log('✅ Battle session reset complete with tokens and initiative!');
    console.log('🎯 Ready for combat - players are on the map and in initiative order!');
  } catch (error) {
    console.error('❌ Error during battle session reset:', error);
    throw error;
  }
}


  // NEW: Create switch card action
  static async createSwitchCardAction(
    sessionId: string,
    payload: {
      playerId: string;
      targetId: string;
      playerPosition: { x: number; y: number };
      targetPosition: { x: number; y: number };
      acRoll: number;
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');

    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    const targetToken = session.tokens[payload.targetId];
    
    if (!playerToken) throw new Error('Player token not found');
    if (!targetToken) throw new Error('Target token not found');

    const action: GMCombatAction = {
      id: `switch-card-${Date.now()}`,
      type: 'ability',
      playerId: payload.playerId,
      targetId: payload.targetId,
      sourcePosition: payload.playerPosition,
      acRoll: payload.acRoll,
      range: 999,
      timestamp: new Date(),
      resolved: false,
      hit: payload.acRoll >= (targetToken.ac || 13),
      needsDamageInput: payload.acRoll >= (targetToken.ac || 13), // If hit, apply damage + switch
      damageApplied: false,
      playerName: playerToken.name,
      targetName: targetToken.name,
      abilityName: 'Switch Card',
      cardType: 'switch',
      switchData: {
        playerId: payload.playerId,
        playerPosition: payload.playerPosition,
        targetPosition: payload.targetPosition
      }
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });

    return action;
  }

  // NEW: Create vanish card action
  static async createVanishCardAction(
    sessionId: string,
    payload: {
      playerId: string;
      targetId: string;
      acRoll: number;
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');

    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    const targetToken = session.tokens[payload.targetId];
    
    if (!playerToken) throw new Error('Player token not found');
    if (!targetToken) throw new Error('Target token not found');

    const currentRound = session.combatState?.round || 1;
    const returnsOnRound = currentRound + 2; // Returns after 2 rounds

    const action: GMCombatAction = {
      id: `vanish-card-${Date.now()}`,
      type: 'ability',
      playerId: payload.playerId,
      targetId: payload.targetId,
      sourcePosition: playerToken.position,
      acRoll: payload.acRoll,
      range: 999,
      timestamp: new Date(),
      resolved: false,
      hit: payload.acRoll >= (targetToken.ac || 13),
      needsDamageInput: payload.acRoll >= (targetToken.ac || 13), // If hit, apply damage + vanish
      damageApplied: false,
      playerName: playerToken.name,
      targetName: targetToken.name,
      abilityName: 'Vanish Card',
      cardType: 'vanish',
      vanishData: {
        targetId: payload.targetId,
        targetName: targetToken.name,
        returnsOnRound: returnsOnRound
      }
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });

    return action;
  }

  // NEW: Apply switch positions after damage is applied
// Replace the applySwitchPositions function in firestoreService.ts with this enhanced debug version:

static async applySwitchPositions(sessionId: string, actionId: string): Promise<void> {
  console.log('=== SWITCH POSITIONS DEBUG ===');
  console.log('Session ID:', sessionId);
  console.log('Action ID:', actionId);
  
  const session = await this.getBattleSession(sessionId);
  if (!session || !session.pendingActions) {
    console.log('❌ Session or pendingActions not found');
    return;
  }
  
  console.log('✅ Session found:', !!session);
  console.log('✅ Pending actions count:', session?.pendingActions?.length || 0);
  
  // Debug: Log all pending action IDs
  console.log('📋 All pending action IDs:');
  session.pendingActions.forEach((a, index) => {
    console.log(`  ${index}: ${a.id} (type: ${a.type}, resolved: ${a.resolved})`);
  });
  
  const action = session.pendingActions.find(a => a.id === actionId) as GMCombatAction | undefined;
  console.log('🔍 Action found:', !!action);
  
  if (!action) {
    console.log('❌ PROBLEM: Action not found in pending actions');
    return;
  }
  
  console.log('📝 Action details:', {
    id: action.id,
    type: action.type,
    cardType: action.cardType,
    resolved: action.resolved,
    hasSwitchData: !!action.switchData
  });
  
  if (!action.switchData) {
    console.log('❌ PROBLEM: Action has no switchData');
    console.log('📋 Full action object:', action);
    return;
  }
  
  if (action.resolved) {
    console.log('❌ PROBLEM: Action already resolved');
    return;
  }
  
  console.log('✅ Switch data present:', action.switchData);
  
  const updatedTokens = { ...session.tokens };
  
  // Find player and target tokens
  const playerToken = Object.values(updatedTokens).find(t => t.characterId === action.playerId);
  const targetToken = updatedTokens[action.targetId!];
  
  console.log('🎭 Player token found:', !!playerToken, playerToken?.name);
  console.log('🎯 Target token found:', !!targetToken, targetToken?.name);
  
  if (!playerToken) {
    console.log('❌ PROBLEM: Player token not found for characterId:', action.playerId);
    console.log('📋 Available tokens:', Object.values(updatedTokens).map(t => ({
      id: t.id,
      name: t.name,
      characterId: t.characterId,
      type: t.type
    })));
    return;
  }
  
  if (!targetToken) {
    console.log('❌ PROBLEM: Target token not found for targetId:', action.targetId);
    return;
  }

  if (playerToken && targetToken) {
    console.log('🔄 BEFORE SWITCH:');
    console.log(`  ${playerToken.name} at (${playerToken.position.x}, ${playerToken.position.y})`);
    console.log(`  ${targetToken.name} at (${targetToken.position.x}, ${targetToken.position.y})`);
    
    // Swap positions
    const tempPosition = { ...playerToken.position };
    playerToken.position = { ...targetToken.position };
    targetToken.position = tempPosition;

    updatedTokens[playerToken.id] = playerToken;
    updatedTokens[targetToken.id] = targetToken;

    console.log('🔄 AFTER SWITCH:');
    console.log(`  ${playerToken.name} at (${playerToken.position.x}, ${playerToken.position.y})`);
    console.log(`  ${targetToken.name} at (${targetToken.position.x}, ${targetToken.position.y})`);
  }

  // Mark action as resolved
  const updatedActions = session.pendingActions.map(a =>
    a.id === actionId ? { ...a, resolved: true, damageApplied: true } : a
  );

  console.log('💾 Updating Firestore...');
  
  const ref = doc(db, 'battleSessions', sessionId);
  await updateDoc(ref, {
    tokens: updatedTokens,
    pendingActions: updatedActions,
    updatedAt: serverTimestamp()
  });
  
  console.log('✅ Firestore update completed');
}

static async updateNPCLevels(sessionId: string, levels: { newRecruit: number; farmhand: number }) {
  const ref = doc(db, 'battleSessions', sessionId);
  await updateDoc(ref, {
    npcLevels: levels,
    updatedAt: serverTimestamp()
  });

  await this.syncNPCLevelsToTokens(sessionId, levels);

}

static async getNPCLevels(sessionId: string): Promise<{ newRecruit: number; farmhand: number }> {
  const session = await this.getBattleSession(sessionId);
  return session?.npcLevels || { newRecruit: 1, farmhand: 1 };
}

// Method to add a summoned entity (Brother's Sword)
static async addSummonedEntity(sessionId: string, entityData: any): Promise<void> {
  try {
    const ref = doc(db, 'battleSessions', sessionId);
    
    // Add the summoned entity as a special token
    await updateDoc(ref, {
      [`tokens.${entityData.id}`]: {
        ...entityData,
        type: 'summon', // Special type for summoned entities
        color: '#9333ea', // Purple for spectral entities
        controllerId: 'the-child' // Who controls this summon
      },
      // Track active summons
      activeSummons: arrayUnion({
        id: entityData.id,
        name: entityData.name,
        summoner: 'the-child',
        roundsRemaining: entityData.roundsRemaining,
        createdAt: Date.now()
      }),
      updatedAt: serverTimestamp()
    });
    
    console.log(`✅ Summoned entity created: ${entityData.name}`);
  } catch (error) {
    console.error('❌ Failed to add summoned entity:', error);
    throw error;
  }

}


  static async applyFixedDamageToEnemy(sessionId: string, actionId: string, damage: number) {
    const session = await this.getBattleSession(sessionId);
    if (!session || !session.pendingActions) return;

    const action = session.pendingActions.find(a => a.id === actionId) as GMCombatAction | undefined;
    if (!action || !action.targetId) return;

    const targetToken = session.tokens[action.targetId];
    if (!targetToken) return;

    const currentHP = Number(targetToken.hp) || 0;
    const newHP = Math.max(0, currentHP - damage);
    
    console.log(`Brother's Sword: Applying ${damage} damage to ${targetToken.name}: ${currentHP} -> ${newHP}`);

    const updatedActions = session.pendingActions.map(a =>
      a.id === actionId ? { ...a, resolved: true, damage: damage, damageApplied: true } : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    
    if (newHP <= 0) {
      // Enemy is dead - remove the token
      const updatedTokens = { ...session.tokens };
      delete updatedTokens[action.targetId];
      
      await updateDoc(ref, { 
        tokens: updatedTokens,
        pendingActions: updatedActions, 
        updatedAt: serverTimestamp() 
      });
      
      console.log(`${targetToken.name} was defeated by Brother's Sword!`);
    } else {
      // Enemy survives - update HP
      await updateDoc(ref, {
        [`tokens.${action.targetId}.hp`]: newHP,
        pendingActions: updatedActions,
        updatedAt: serverTimestamp()
      });
    }
  }

// Method to apply status effects (pin/slow/restrain)
static async applyStatusEffect(
  sessionId: string, 
  targetId: string, 
  effect: 'pin-slow' | 'pin-restrain' | string
): Promise<void> {
  try {
    const session = await this.getBattleSession(sessionId);
    if (!session?.tokens[targetId]) {
      console.warn(`Target ${targetId} not found`);
      return;
    }
    
    const ref = doc(db, 'battleSessions', sessionId);
    const currentRound = session.combatState?.round || 1;
    
    // Initialize statusEffects if it doesn't exist
    const statusEffectData = {
      turnsRemaining: effect === 'pin-slow' ? 1 : 2, // Slow for 1 turn, restrain for 2
      appliedBy: 'The Child',
      appliedOnRound: currentRound,
      description: effect === 'pin-slow' 
        ? 'Speed reduced by 10ft' 
        : 'Restrained (DC 13 STR to break)'
    };
    
    // Update the token with the status effect
    await updateDoc(ref, {
      [`tokens.${targetId}.statusEffects.${effect.replace('-', '_')}`]: statusEffectData,
      // Also reduce movement for pinned targets
      [`tokens.${targetId}.movement`]: effect === 'pin-slow' ? 20 : 0,
      updatedAt: serverTimestamp()
    });
    
    console.log(`✅ Applied ${effect} to ${session.tokens[targetId].name}`);
  } catch (error) {
    console.error(`❌ Failed to apply status effect:`, error);
    throw error;
  }
}

static async cleanupExpiredSummons(sessionId: string): Promise<void> {
  const session = await this.getBattleSession(sessionId);
  if (!session?.activeSummons) return;
  
  const currentRound = session.combatState?.round || 1;
  const updatedTokens = { ...session.tokens };
  let needsUpdate = false;
  
  // Filter out expired summons
  const activeSummons = session.activeSummons.filter((summon: any) => {
    // Check if summon has expired
    if (summon.expiresOnRound && currentRound >= summon.expiresOnRound) {
      // Remove the summon token
      if (updatedTokens[summon.id]) {
        delete updatedTokens[summon.id];
        needsUpdate = true;
        console.log(`⚔️ ${summon.name} vanished after 3 rounds`);
      }
      return false; // Remove from activeSummons
    }
    return true; // Keep in activeSummons
  });
  
  if (needsUpdate) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      tokens: updatedTokens,
      activeSummons: activeSummons,
      updatedAt: serverTimestamp()
    });
  }
}

// Method to control the Brother's Sword on The Child's turn
static async getBrothersSword(sessionId: string): Promise<any | null> {
  const session = await this.getBattleSession(sessionId);
  if (!session?.activeSummons) return null;
  
  const sword = session.activeSummons.find((s: any) => 
    s.name === "Brother's Sword" && s.summoner === 'the-child'
  );
  
  if (!sword) return null;
  
  // Get the actual token data
  const swordToken = session.tokens[sword.id];
  return swordToken || null;
}

// Method to move the Brother's Sword
static async moveBrothersSword(
  sessionId: string, 
  swordId: string, 
  newPosition: { x: number; y: number }
): Promise<void> {
  const ref = doc(db, 'battleSessions', sessionId);
  await updateDoc(ref, {
    [`tokens.${swordId}.position`]: newPosition,
    updatedAt: serverTimestamp()
  });
  console.log(`⚔️ Brother's Sword moved to (${newPosition.x}, ${newPosition.y})`);
}

// NEW: Apply vanish effect after damage is applied
static async applyVanishEffect(sessionId: string, actionId: string): Promise<void> {
  const session = await this.getBattleSession(sessionId);
  if (!session || !session.pendingActions) return;

  const action = session.pendingActions.find(a => a.id === actionId) as GMCombatAction | undefined;
  if (!action || !action.vanishData || action.resolved) return;

  const targetToken = session.tokens[action.targetId!];
  if (!targetToken) return;

  // Create vanished enemy record
  const vanishedEnemy: VanishedEnemy = {
    id: action.vanishData.targetId,
    enemyData: { ...targetToken },
    vanishedOnRound: session.combatState?.round || 1,
    returnsOnRound: action.vanishData.returnsOnRound,
    vanishedBy: action.playerId
  };

  // Remove token from battlefield
  const updatedTokens = { ...session.tokens };
  delete updatedTokens[action.targetId!];

  // Mark action as resolved
  const updatedActions = session.pendingActions.map(a =>
    a.id === actionId ? { ...a, resolved: true, damageApplied: true } : a
  );

  const ref = doc(db, 'battleSessions', sessionId);
  await updateDoc(ref, {
    tokens: updatedTokens,
    pendingActions: updatedActions,
    vanishedEnemies: arrayUnion(vanishedEnemy),
    updatedAt: serverTimestamp()
  });

  console.log(`${targetToken.name} vanished until round ${action.vanishData.returnsOnRound}`);
}

// NEW: Process buff/debuff expirations and vanished enemy returns
static async processBuffsAndVanishedEnemies(sessionId: string): Promise<void> {
  const session = await this.getBattleSession(sessionId);
  if (!session) return;

  const currentRound = session.combatState?.round || 1;
  let needsUpdate = false;
  const updates: any = {};

  // Process active buffs
  if (session.activeBuffs) {
    const beforeCount = session.activeBuffs.length;
    const activeBuffs = session.activeBuffs.filter((buff: ActiveBuff) => {
      const roundsElapsed = currentRound - buff.appliedOnRound;
      const shouldKeep = roundsElapsed < buff.duration;
      if (!shouldKeep) {
        console.log(`Expired buff: ${buff.type} on ${buff.targetName}`);
      }
      return shouldKeep;
    });
    
    if (activeBuffs.length !== beforeCount) {
      updates.activeBuffs = activeBuffs;
      needsUpdate = true;
      console.log(`Cleaned up ${beforeCount - activeBuffs.length} expired buffs`);
    }
  }

  // Process vanished enemies
  if (session.vanishedEnemies) {
    const beforeCount = session.vanishedEnemies.length;
    const returningEnemies: VanishedEnemy[] = [];
    const stillVanished: VanishedEnemy[] = [];

    session.vanishedEnemies.forEach((vanished: VanishedEnemy) => {
      if (currentRound >= vanished.returnsOnRound) {
        returningEnemies.push(vanished);
      } else {
        stillVanished.push(vanished);
      }
    });

    if (returningEnemies.length > 0) {
      // Return vanished enemies to battlefield
      const updatedTokens = { ...session.tokens };
      returningEnemies.forEach(vanished => {
        updatedTokens[vanished.id] = vanished.enemyData;
        console.log(`${vanished.enemyData.name} returned from vanish on round ${currentRound}`);
      });
      updates.tokens = updatedTokens;
      updates.vanishedEnemies = stillVanished;
      needsUpdate = true;
    } else if (stillVanished.length !== beforeCount) {
      updates.vanishedEnemies = stillVanished;
      needsUpdate = true;
    }
  }

  if (needsUpdate) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      ...updates,
      updatedAt: serverTimestamp()
    });
    console.log('Processed buffs and vanished enemies');
  }
}



  // ========== BATTLE MAP PRESET MANAGEMENT ==========

  /**
   * Save a battle map preset
   */
  static async saveBattleMapPreset(sessionId: string, presetData: PresetSaveData): Promise<string> {
    try {
      const presetId = `preset_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const presetRef = doc(db, 'battleMapPresets', presetId);
      
      const preset: BattleMapPreset = {
        id: presetId,
        name: presetData.name,
        description: presetData.description || '',
        mapId: presetData.mapId,
        tokens: presetData.tokens,
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: sessionId // Using sessionId as creator identifier
      };

      await setDoc(presetRef, preset);
      console.log(`✅ Battle map preset saved: ${presetData.name}`);
      return presetId;
    } catch (error) {
      console.error('❌ Failed to save battle map preset:', error);
      throw error;
    }
  }

  /**
   * Load all presets for a specific map
   */
  static async getBattleMapPresets(mapId?: string): Promise<BattleMapPreset[]> {
    try {
      const presetsRef = collection(db, 'battleMapPresets');
      let presetsQuery;
      
      if (mapId) {
        presetsQuery = query(
          presetsRef, 
          where('mapId', '==', mapId),
          orderBy('createdAt', 'desc')
        );
      } else {
        presetsQuery = query(presetsRef, orderBy('createdAt', 'desc'));
      }
      
      const snapshot = await getDocs(presetsQuery);
      const presets: BattleMapPreset[] = [];
      
      snapshot.forEach((doc) => {
        const data = doc.data();
        presets.push({
          ...data,
          createdAt: data.createdAt?.toDate() || new Date(),
          updatedAt: data.updatedAt?.toDate() || new Date()
        } as BattleMapPreset);
      });
      
      console.log(`✅ Retrieved ${presets.length} presets${mapId ? ` for map ${mapId}` : ''}`);
      return presets;
    } catch (error) {
      console.error('❌ Failed to get battle map presets:', error);
      return [];
    }
  }
  
  static async initializeInventoryForAllCharacters(): Promise<void> {
    try {
      const characterIds = ['maelle', 'gustave', 'lune', 'sciel']; // Your existing character IDs
      
      for (const characterId of characterIds) {
        const characterRef = doc(db, 'characters', characterId);
        const characterSnap = await getDoc(characterRef);
        
        if (characterSnap.exists()) {
          const data = characterSnap.data();
          
          // Only add inventory if it doesn't exist
          if (!data.inventory) {
            await updateDoc(characterRef, {
              inventory: [],
              updatedAt: serverTimestamp()
            });
            console.log(`✅ Added empty inventory to ${characterId}`);
          } else {
            console.log(`ℹ️ ${characterId} already has inventory`);
          }
        }
      }
      
      console.log('✅ Inventory initialization completed');
    } catch (error) {
      console.error('❌ Failed to initialize inventories:', error);
      throw error;
    }
  }


  /**
   * Load a battle map preset onto the current session
   */
  static async loadBattleMapPreset(sessionId: string, presetId: string): Promise<void> {
    try {
      const presetsRef = collection(db, 'battleMapPresets');
      const snapshot = await getDocs(query(presetsRef, where('id', '==', presetId)));
      
      if (snapshot.empty) {
        throw new Error(`Preset ${presetId} not found`);
      }
      
      const presetData = snapshot.docs[0].data() as BattleMapPreset;
      const sessionRef = doc(db, 'battleSessions', sessionId);
      
      // Get existing session to preserve map configuration
      const existingSession = await this.getBattleSession(sessionId);
      if (!existingSession) {
        throw new Error('Session not found');
      }
      
      // FIXED: Only update tokens, preserve existing map configuration
      await updateDoc(sessionRef, {
        tokens: presetData.tokens,
        // Don't overwrite currentMap - preserve existing map with background image
        // currentMap: { id: presetData.mapId }, // ❌ REMOVED THIS LINE
        updatedAt: serverTimestamp()
      });
      
      console.log(`✅ Loaded battle map preset: ${presetData.name}`);
      console.log(`📍 Loaded ${Object.keys(presetData.tokens).length} tokens`);
      console.log(`🗺️ Preserved existing map configuration`);
    } catch (error) {
      console.error('❌ Failed to load battle map preset:', error);
      throw error;
    }
  }
  /**
   * Delete a battle map preset
   */
  static async deleteBattleMapPreset(presetId: string): Promise<void> {
    try {
      const presetRef = doc(db, 'battleMapPresets', presetId);
      await deleteDoc(presetRef);
      console.log(`✅ Deleted battle map preset: ${presetId}`);
    } catch (error) {
      console.error('❌ Failed to delete battle map preset:', error);
      throw error;
    }
  }

  /**
   * Update an existing battle map preset
   */
  static async updateBattleMapPreset(presetId: string, updates: Partial<PresetSaveData>): Promise<void> {
    try {
      const presetRef = doc(db, 'battleMapPresets', presetId);
      await updateDoc(presetRef, {
        ...updates,
        updatedAt: new Date()
      });
      console.log(`✅ Updated battle map preset: ${presetId}`);
    } catch (error) {
      console.error('❌ Failed to update battle map preset:', error);
      throw error;
    }
  }


  // ========== Characters ==========
  static async getCharacter(characterId: string): Promise<Character | null> {
    try {
      const characterRef = doc(db, 'characters', characterId);
      const characterSnap = await getDoc(characterRef);

      if (!characterSnap.exists()) {
        console.warn(`Character ${characterId} not found`);
        return null;
      }

      const data = characterSnap.data() as CharacterDoc;
      
      // Convert Firebase timestamps and ensure combat state exists
      const character: Character = {
        id: characterId,
        name: data.name,
        role: data.role,
        stats: data.stats,
        currentHP: data.currentHP,
        maxHP: data.maxHP,
        abilities: data.abilities,
        stance: data.stance,
        charges: data.charges,
        maxCharges: data.maxCharges,
        level: data.level,
        portraitUrl: data.portraitUrl,
        backgroundColor: data.backgroundColor,
        inventory: data.inventory || [],
        gold: data.gold || 0,
        
        // NEW: Include combat state, create default if missing
      combatState: data.combatState ? {
        // Start with defaults to ensure all properties exist
        ...CombatStateHelpers.createDefaultCombatState(),
        // Override with saved values
        ...data.combatState,
        lastUpdated: data.combatState.lastUpdated?.toDate() || new Date(),
        lastSyncedAt: data.combatState.lastSyncedAt?.toDate() || new Date()
      } : CombatStateHelpers.createDefaultCombatState(),
        
        // Maelle afterimage state
        afterimageStacks: data.afterimageStacks,
        maxAfterimageStacks: data.maxAfterimageStacks,
        phantomStrikeUsed: data.phantomStrikeUsed
      };

      console.log(`✅ Loaded character ${characterId} with combat state:`, character.combatState);
      return character;
    } catch (error) {
      console.error(`Error fetching character ${characterId}:`, error);
      return null;
    }
  }

  static async updateCharacterCombatState(
    characterId: string, 
    combatState: Partial<CharacterCombatState>
  ): Promise<void> {
    try {
      const characterRef = doc(db, 'characters', characterId);
      
      // Prepare update data with server timestamps
      const updateData = {
        combatState: {
          ...combatState,
          lastUpdated: serverTimestamp(),
          lastSyncedAt: serverTimestamp()
        }
      };

      await updateDoc(characterRef, updateData);
      console.log(`💾 Updated combat state for ${characterId}:`, combatState);
    } catch (error) {
      console.error(`❌ Failed to update combat state for ${characterId}:`, error);
      throw error;
    }
  }

  static async resetCharacterCombatState(characterId: string): Promise<void> {
    try {
      const defaultState = CombatStateHelpers.createDefaultCombatState();
      await this.updateCharacterCombatState(characterId, defaultState);
      console.log(`🔄 Reset combat state for ${characterId}`);
    } catch (error) {
      console.error(`❌ Failed to reset combat state for ${characterId}:`, error);
      throw error;
    }
  }

    static async initializeCharacterCombatState(characterId: string): Promise<void> {
    try {
      const character = await this.getCharacter(characterId);
      if (!character || character.combatState) {
        return; // Already has combat state
      }

      const defaultState = CombatStateHelpers.createDefaultCombatState();
      await this.updateCharacterCombatState(characterId, defaultState);
      console.log(`📝 Initialized combat state for ${characterId}`);
    } catch (error) {
      console.error(`❌ Failed to initialize combat state for ${characterId}:`, error);
      throw error;
    }
  }



  static async updateCharacterHP(characterId: string, newHP: number) {
    const ref = doc(db, 'characters', characterId);
    await updateDoc(ref, {
      currentHP: Math.max(0, newHP),
      updatedAt: serverTimestamp()
    });
  }

  static async updateCharacterStance(characterId: string, stance: string) {
    const ref = doc(db, 'characters', characterId);
    await updateDoc(ref, { stance, updatedAt: serverTimestamp() });
  }

  static async updateCharacterCharges(characterId: string, charges: number) {
    const ref = doc(db, 'characters', characterId);
    await updateDoc(ref, {
      charges: Math.max(0, Math.min(charges, 5)),
      updatedAt: serverTimestamp()
    });
  }

  static async updateBattleSession(sessionId: string, updates: any): Promise<void> {
    const sessionRef = doc(db, 'battleSessions', sessionId);
    await updateDoc(sessionRef, updates);
  }

  static async updateCharacter(characterId: string, updates: any): Promise<void> {
    const characterRef = doc(db, 'characters', characterId);
    await updateDoc(characterRef, updates);
  }

  // Enhanced updateTokenHP that removes dead enemies (replace existing method)
  static async updateTokenHP(sessionId: string, tokenId: string, newHP: number) {
    const session = await this.getBattleSession(sessionId);
    if (!session?.tokens[tokenId]) return;

    const currentHP = Math.max(0, newHP);
    
    if (currentHP <= 0) {
      // Enemy is dead - remove the token entirely
      const updatedTokens = { ...session.tokens };
      delete updatedTokens[tokenId];
      
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, { 
        tokens: updatedTokens,
        updatedAt: serverTimestamp() 
      });
      
      console.log(`Token ${tokenId} died and was removed`);
    } else {
      // Token survives - just update HP
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        [`tokens.${tokenId}.hp`]: currentHP,
        updatedAt: serverTimestamp()
      });
    }
  }

  // ========== ENHANCED TOKEN MANAGEMENT FOR EXPEDITION NPCS ==========
  
  /**
   * Enhanced addToken method with better error handling and validation
   */
  static async addToken(sessionId: string, token: BattleToken): Promise<void> {
    try {
      const ref = doc(db, 'battleSessions', sessionId);
      
      // Validate token data
      if (!token.id || !token.name || !token.position || !token.type) {
        throw new Error('Invalid token data: missing required fields');
      }

      // Ensure token has required properties for its type
      const tokenToAdd = {
        ...token,
        hp: token.hp ?? (token.type === 'npc' ? 20 : token.hp),
        maxHp: token.maxHp ?? (token.type === 'npc' ? 20 : token.maxHp),
        ac: token.ac ?? 13,
        size: token.size ?? 1,
        color: token.color ?? this.getDefaultColorForType(token.type)
      };

      await updateDoc(ref, { 
        [`tokens.${token.id}`]: tokenToAdd, 
        updatedAt: serverTimestamp() 
      });

      console.log(`✅ ${token.type.toUpperCase()} token added:`, token.name);
    } catch (error) {
      console.error('❌ Failed to add token:', error);
      throw error;
    }
  }

  /**
   * Enhanced removeToken method with type-aware logging
   */
  static async removeToken(sessionId: string, tokenId: string): Promise<void> {
    try {
      const session = await this.getBattleSession(sessionId);
      if (!session?.tokens[tokenId]) {
        console.warn(`Token ${tokenId} not found in session ${sessionId}`);
        return;
      }

      const tokenToRemove = session.tokens[tokenId];
      const updated = { ...session.tokens };
      delete updated[tokenId];
      
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, { 
        tokens: updated, 
        updatedAt: serverTimestamp() 
      });

      console.log(`✅ ${tokenToRemove.type?.toUpperCase()} removed:`, tokenToRemove.name);
    } catch (error) {
      console.error('❌ Failed to remove token:', error);
      throw error;
    }
  }

  /**
   * Get tokens by type (useful for GM management)
   */
  static async getTokensByType(sessionId: string, tokenType: 'player' | 'enemy' | 'npc'): Promise<BattleToken[]> {
    try {
      const session = await this.getBattleSession(sessionId);
      if (!session?.tokens) return [];

      return Object.values(session.tokens).filter(token => token.type === tokenType);
    } catch (error) {
      console.error('❌ Failed to get tokens by type:', error);
      return [];
    }
  }

  /**
   * Bulk remove tokens by type (useful for clearing enemies/NPCs)
   */
  static async removeTokensByType(sessionId: string, tokenType: 'enemy' | 'npc'): Promise<void> {
    try {
      const session = await this.getBattleSession(sessionId);
      if (!session?.tokens) return;

      const tokensToKeep = Object.entries(session.tokens)
        .filter(([_, token]) => token.type !== tokenType)
        .reduce((acc, [id, token]) => ({ ...acc, [id]: token }), {});

      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, { 
        tokens: tokensToKeep, 
        updatedAt: serverTimestamp() 
      });

      console.log(`✅ All ${tokenType} tokens removed from session`);
    } catch (error) {
      console.error(`❌ Failed to remove ${tokenType} tokens:`, error);
      throw error;
    }
  }

  /**
   * Update token properties (HP, position, etc.)
   */
  static async updateTokenProperty(sessionId: string, tokenId: string, property: string, value: any): Promise<void> {
    try {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        [`tokens.${tokenId}.${property}`]: value,
        updatedAt: serverTimestamp()
      });

      console.log(`✅ Token ${tokenId} ${property} updated to:`, value);
    } catch (error) {
      console.error(`❌ Failed to update token ${property}:`, error);
      throw error;
    }
  }

  /**
   * Get default color for token type
   */
  private static getDefaultColorForType(tokenType: 'player' | 'enemy' | 'npc'): string {
    switch (tokenType) {
      case 'player':
        return '#4f46e5'; // Blue
      case 'enemy':
        return '#dc2626'; // Red
      case 'npc':
        return '#16a34a'; // Green
      default:
        return '#6b7280'; // Gray
    }
  }

  /**
   * Validate token placement on the map
   */
  static validateTokenPlacement(
    position: Position, 
    mapWidth: number = 20, 
    mapHeight: number = 15, 
    existingTokens: BattleToken[] = []
  ): { valid: boolean; reason?: string } {
    // Check bounds
    if (position.x < 0 || position.x >= mapWidth || position.y < 0 || position.y >= mapHeight) {
      return { valid: false, reason: 'Position is outside map bounds' };
    }

    // Check for overlapping tokens (optional - remove if you allow stacking)
    const hasOverlap = existingTokens.some(token => 
      token.position.x === position.x && token.position.y === position.y
    );
    
    if (hasOverlap) {
      return { valid: false, reason: 'Another token is already at this position' };
    }

    return { valid: true };
  }

  // ========== GM Actions ==========
  // Single-target attack -> push into pendingActions
  static async createAttackAction(
    sessionId: string,
    playerId: string,
    targetId: string,
    sourcePosition: Position,
    acRoll: number,
    abilityName: string = 'Basic Attack'
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');

    const playerToken = Object.values(session.tokens).find(t => t.characterId === playerId);
    const targetToken = session.tokens[targetId];
    if (!playerToken || !targetToken) throw new Error('Player or target not found');

    const targetAC = targetToken.ac ?? 13;
    const hit = acRoll >= targetAC;

    const action: GMCombatAction = {
      id: `action-${Date.now()}`,
      type: 'attack',
      playerId,
      targetId,
      sourcePosition,
      acRoll,
      range: 5,
      timestamp: new Date(),
      resolved: false,
      hit,
      playerName: playerToken.name,
      targetName: targetToken.name,
      abilityName,
      needsDamageInput: hit,
      damageApplied: false
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });

    return action;
  }

  // AoE action -> one GM action with many targets
  static async createAoEAction(
    sessionId: string,
    payload: {
      playerId: string;
      abilityName?: string;
      targetIds: string[];
      targetNames?: string[];
      center?: { x: number; y: number };
      radius?: number;
      acRoll?: number; // optional label for UI
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');
    if (!payload.playerId) throw new Error('Player not found');
    if (!payload.targetIds?.length) throw new Error('No targets in range');

    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);

    const action: GMCombatAction = {
      id: `action-${Date.now()}`,
      type: 'ability',
      playerId: payload.playerId,
      sourcePosition: payload.center ?? playerToken?.position ?? { x: 0, y: 0 },
      acRoll: payload.acRoll ?? 999, // label only
      range: payload.radius ?? 30,
      timestamp: new Date(),
      resolved: false,
      // IMPORTANT: mark as hit & needsDamageInput so popup shows HIT without AC
      hit: true,
      needsDamageInput: true,
      damageApplied: false,
      playerName: playerToken?.name,
      abilityName: payload.abilityName ?? 'Overcharge Burst',
      targetIds: payload.targetIds,
      targetNames: payload.targetNames
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });

    return action;
  }

  // Apply one damage number to all targets in an AoE action
  static async applyAoEDamage(sessionId: string, actionId: string, damage: number): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session || !session.pendingActions) return;

    const action = session.pendingActions.find(a => a.id === actionId) as GMCombatAction | undefined;
    if (!action || !action.targetIds?.length || action.resolved) {
      console.log('Action already resolved or not found');
      return;
    }

    const updatedTokens = { ...session.tokens };
    const deadEnemyIds: string[] = []; // Track which enemies died

    for (const tid of action.targetIds) {
      const tok = updatedTokens[tid];
      if (!tok) continue;
      
      const currentHP = Number(tok.hp) || 0;
      const damageAmount = Number(damage) || 0;
      const newHP = Math.max(0, currentHP - damageAmount);
      
      console.log(`Applying ${damageAmount} damage to ${tok.name}: ${currentHP} -> ${newHP}`);
      
      if (newHP <= 0) {
        // Enemy is dead - mark for removal
        deadEnemyIds.push(tid);
        console.log(`${tok.name} died and will be removed`);
      } else {
        // Enemy survives - update HP
        updatedTokens[tid] = { ...tok, hp: newHP };
      }
    }

    // Remove dead enemies from the tokens object
    deadEnemyIds.forEach(id => {
      delete updatedTokens[id];
    });

    const updatedActions = session.pendingActions.map(a =>
      a.id === actionId ? { ...a, resolved: true, damageApplied: true, damage } : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      tokens: updatedTokens,
      pendingActions: updatedActions,
      updatedAt: serverTimestamp()
    });

    console.log(`AoE damage applied. ${deadEnemyIds.length} enemies removed.`);
  }

    // NEW: Create buff/debuff action with token status effect
  static async createBuffAction(
    sessionId: string,
    payload: {
      playerId: string;
      targetId: string;
      abilityName: string;
      buffType: 'advantage' | 'disadvantage';
      duration: number; // Number of turns
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');

    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    const targetToken = session.tokens[payload.targetId] || 
      Object.values(session.tokens).find(t => t.characterId === payload.targetId);
    
    if (!playerToken) throw new Error('Player token not found');
    if (!targetToken) throw new Error('Target token not found');

    const action: GMCombatAction = {
      id: `buff-${Date.now()}`,
      type: 'ability',
      playerId: payload.playerId,
      targetId: payload.targetId,
      sourcePosition: playerToken.position,
      acRoll: 0, // Not relevant for buffs
      range: 0,
      timestamp: new Date(),
      resolved: false,
      hit: true, // Buffs always "hit"
      needsDamageInput: false,
      damageApplied: false,
      playerName: playerToken.name,
      targetName: targetToken.name,
      abilityName: payload.abilityName,
      buffType: payload.buffType,
      duration: payload.duration
    };

    // Apply the buff to activeBuffs
    const currentRound = session.combatState?.round || 1;
    const newBuff: ActiveBuff = {
      id: action.id,
      type: payload.buffType,
      targetId: payload.targetId,
      targetName: targetToken.name,
      sourcePlayer: payload.playerId,
      appliedOnRound: currentRound,
      duration: payload.duration,
      turnsRemaining: payload.duration,
      createdAt: Date.now()
    };

    // IMPORTANT: Apply status effect directly to the target token
    const updatedTokens = { ...session.tokens };
    const targetTokenKey = payload.targetId;
    
    if (updatedTokens[targetTokenKey]) {
      // Initialize statusEffects if it doesn't exist
      if (!updatedTokens[targetTokenKey].statusEffects) {
        updatedTokens[targetTokenKey].statusEffects = {};
      }
      
      // Apply the buff as a status effect on the token (matching your structure)
      if (payload.buffType === 'advantage') {
        updatedTokens[targetTokenKey].statusEffects!.advantage = {
          turnsRemaining: payload.duration,
          source: playerToken.name,
          appliedBy: payload.abilityName,
          appliedOnRound: currentRound // Add this to match your existing structure
        };
      } else if (payload.buffType === 'disadvantage') {
        updatedTokens[targetTokenKey].statusEffects!.disadvantage = {
          turnsRemaining: payload.duration,
          source: playerToken.name,
          appliedBy: payload.abilityName,
          appliedOnRound: currentRound // Add this to match your existing structure
        };
      }
    }

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      activeBuffs: arrayUnion(newBuff),
      tokens: updatedTokens, // Update tokens with new status effects
      updatedAt: serverTimestamp()
    });

    console.log(`Applied ${payload.buffType} to ${targetToken.name} for ${payload.duration} turns with visual indicator`);
    return action;
  }

// Replace the existing advanceTurnWithBuffs function with this corrected version:
  

static async advanceTurnWithBuffs(sessionId: string, nextPlayerId: string) {
  const session = await this.getBattleSession(sessionId);
  if (!session || !session.combatState) return;

  // Find current turn index to determine if we're starting a new round
  const currentTurnIndex = session.combatState.turnOrder.indexOf(session.combatState.currentTurn);
  const nextTurnIndex = session.combatState.turnOrder.indexOf(nextPlayerId);
  const isNewRound = nextTurnIndex === 0 && currentTurnIndex > 0;

  // Update combat state - FIXED: Use 'currentTurn' instead of 'currentPlayer'
  const updatedCombatState = {
    ...session.combatState,
    currentTurn: nextPlayerId, // FIXED: Changed from 'currentPlayer' to 'currentTurn'
    round: isNewRound ? session.combatState.round + 1 : session.combatState.round
  };

  // Handle buff duration and token status effects
  let updatedBuffs = [...(session.activeBuffs || [])];
  const updatedTokens = { ...session.tokens };
  let tokensChanged = false;

  // Process each buff
  updatedBuffs = updatedBuffs.map(buff => {
    let updatedBuff = { ...buff };
    const isTargetsTurn = buff.targetId === nextPlayerId || 
      updatedTokens[buff.targetId]?.characterId === nextPlayerId;

    // Special handling for disadvantage - expires at START of target's turn
    if (buff.type === 'disadvantage' && isTargetsTurn) {
      updatedBuff.turnsRemaining = 0;
      console.log(`Disadvantage expires at start of ${buff.targetName}'s turn`);
    } 
    // Regular turn countdown for advantage
    else if (buff.type === 'advantage') {
      updatedBuff.turnsRemaining = Math.max(0, buff.turnsRemaining - 1);
    }

    // Remove status effect from token if buff expired
    if (updatedBuff.turnsRemaining <= 0) {
      const targetToken = updatedTokens[buff.targetId];
      if (targetToken && targetToken.statusEffects) {
        if (buff.type === 'advantage' && targetToken.statusEffects.advantage) {
          delete targetToken.statusEffects.advantage;
          tokensChanged = true;
          console.log(`Removed advantage status from ${buff.targetName}`);
        }
        if (buff.type === 'disadvantage' && targetToken.statusEffects.disadvantage) {
          delete targetToken.statusEffects.disadvantage;
          tokensChanged = true;
          console.log(`Removed disadvantage status from ${buff.targetName}`);
        }
      }
    }

    return updatedBuff;
  });

  // Filter out expired buffs
  const activeBuffs = updatedBuffs.filter(buff => buff.turnsRemaining > 0);

  // Update Firestore
  const ref = doc(db, 'battleSessions', sessionId);
  const updateData: any = {
    combatState: updatedCombatState,
    activeBuffs: activeBuffs,
    updatedAt: serverTimestamp()
  };

  if (tokensChanged) {
    updateData.tokens = updatedTokens;
  }

  await updateDoc(ref, updateData);

  console.log(`Turn advanced to ${nextPlayerId}, ${updatedBuffs.length - activeBuffs.length} buffs expired`);
}
  // Helper function to check if a token has specific buffs
  static getTokenBuffs(session: any, tokenId: string): {advantage: boolean, disadvantage: boolean} {
    if (!session.activeBuffs) return {advantage: false, disadvantage: false};
    
    const tokenBuffs = session.activeBuffs.filter((buff: ActiveBuff) => 
      buff.targetId === tokenId && buff.turnsRemaining > 0
    );

    return {
      advantage: tokenBuffs.some((buff: ActiveBuff) => buff.type === 'advantage'),
      disadvantage: tokenBuffs.some((buff: ActiveBuff) => buff.type === 'disadvantage')
    };
  }

  // Single-target damage resolution (from GM popup)
  static async applyDamageToEnemy(sessionId: string, actionId: string, damageAmount: number) {
    const session = await this.getBattleSession(sessionId);
    if (!session || !session.pendingActions) return;

    const action = session.pendingActions.find(a => a.id === actionId) as GMCombatAction | undefined;
    if (!action || !action.targetId) return;

    const targetToken = session.tokens[action.targetId];
    if (!targetToken) return;

    const currentHP = Number(targetToken.hp) || 0;
    const newHP = Math.max(0, currentHP - damageAmount);
    
    console.log(`Applying ${damageAmount} damage to ${targetToken.name}: ${currentHP} -> ${newHP}`);

      const hasSpecialEffect = action.cardType === 'switch' || action.cardType === 'vanish';


    const updatedActions = session.pendingActions.map(a =>
      a.id === actionId ? { ...a, resolved: hasSpecialEffect ? false : true, damage: damageAmount, damageApplied: true } : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    
    if (newHP <= 0) {
      // Enemy is dead - remove the token entirely
      const updatedTokens = { ...session.tokens };
      delete updatedTokens[action.targetId];
      
      await updateDoc(ref, { 
        tokens: updatedTokens,
        pendingActions: updatedActions, 
        updatedAt: serverTimestamp() 
      });
      
      console.log(`${targetToken.name} died and was removed`);
    } else {
      // Enemy survives - just update HP
      await updateDoc(ref, {
        [`tokens.${action.targetId}.hp`]: newHP,
        pendingActions: updatedActions,
        updatedAt: serverTimestamp()
      });
    }
  }

  // ========== NEW: Ultimate Actions for Elemental Genesis ==========
  static async createUltimateAction(
    sessionId: string,
    payload: {
      playerId: string;
      ultimateType: string;
      element: 'fire' | 'ice' | 'nature' | 'light';
      effectName: string;
      description: string;
      needsGMInteraction: boolean; // Fire and Ice need GM clicks
      wallType?: 'row' | 'column'; // ADD THIS LINE
      allPlayerTokens?: Array<{
        id: string;
        name: string;
        currentHP: number;
        maxHP: number;
        position: { x: number; y: number };
      }>;
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');
    if (!payload.playerId) throw new Error('Player not found');

    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    if (!playerToken) throw new Error('Player token not found');

    const action: GMCombatAction = {
      id: `ultimate-${Date.now()}`,
      type: 'ability',
      playerId: payload.playerId,
      sourcePosition: playerToken.position,
      acRoll: 999, // Ultimates don't need AC
      range: 0, // Ultimate range varies by element
      timestamp: new Date(),
      resolved: false,
      hit: true, // Ultimates always "hit"
      needsDamageInput: false, // Most ultimates don't need damage input
      damageApplied: false,
      playerName: playerToken.name,
      abilityName: `${payload.effectName} (${payload.element.charAt(0).toUpperCase() + payload.element.slice(1)})`,
      
      // Ultimate-specific data
      ultimateType: payload.ultimateType,
      element: payload.element,
      effectName: payload.effectName,
      description: payload.description,
      needsGMInteraction: payload.needsGMInteraction,

      ...(payload.element === 'ice' && payload.wallType && {
        wallType: payload.wallType
      }),
      
      // For Nature element - healing data
      ...(payload.element === 'nature' && {
        healingTargets: payload.allPlayerTokens
      }),
      
      // For Light element - random square data  
      ...(payload.element === 'light' && {
        affectedSquares: this.generateRandomSquares(20) // Generate 20 random squares
      })
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });

  if (!payload.needsGMInteraction) {
    
    if (payload.element === 'nature') {
      console.log('🌿 Processing nature healing...');
      // Apply healing immediately
      await this.applyNatureHealing(sessionId, payload.allPlayerTokens || []);
    }
    
    if (payload.element === 'light') {
      
      try {
        const lightSquares = this.generateRandomSquares(20);
        console.log('⚡ Generated light squares:', lightSquares);
        
        const lightBlindEffect = {
          id: `light-${Date.now()}`,
          affectedSquares: lightSquares,
          duration: 3,
          turnsRemaining: 3,
          createdBy: payload.playerId,
          createdAt: Date.now(),
          createdOnRound: session.combatState?.round || 1
        };
                
        // Update session with light blind effects
        await updateDoc(ref, {
          lightBlindEffects: arrayUnion(lightBlindEffect),
          updatedAt: serverTimestamp()
        });
        
        
        // 🔧 DEBUG: Verify the update worked
        setTimeout(async () => {
          const verifySession = await this.getBattleSession(sessionId);
          console.log('🔧 DEBUG: Verification - Light effects in session:', verifySession?.lightBlindEffects);
        }, 1000);
        
      } catch (error) {
        console.error('❌ LIGHT ULTIMATE: Failed to create light effects:', error);
        throw error; // Re-throw to see the full error
      }
    }
  } else {
    console.log('🔧 DEBUG: Element needs GM interaction, skipping immediate effects');
  }

    return action;
  }

  
  // Apply Nature healing to all player tokens
  static async applyNatureHealing(
    sessionId: string, 
    playerTokens: Array<{
      id: string;
      name: string;
      currentHP: number;
      maxHP: number;
      position: { x: number; y: number };
    }>
  ): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return;

    const updatedTokens = { ...session.tokens };
    
    // Heal all player tokens by 50% of current HP
    for (const playerData of playerTokens) {
      const token = updatedTokens[playerData.id];
      if (token && token.type === 'player') {
        const healAmount = Math.floor(playerData.currentHP * 0.5);
        const newHP = Math.min(playerData.maxHP, playerData.currentHP + healAmount);
        
        // Update token HP
        updatedTokens[playerData.id] = {
          ...token,
          hp: newHP
        };
        
        // Also update character document
        if (token.characterId) {
          await this.updateCharacterHP(token.characterId, newHP);
        }
        
        console.log(`Nature Genesis: Healed ${playerData.name} for ${healAmount} (${playerData.currentHP} -> ${newHP})`);
      }
    }

    // Update session with new token HP values
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      tokens: updatedTokens,
      updatedAt: serverTimestamp()
    });
  }

  private static generateRandomSquares(count: number): Array<{ x: number; y: number }> {
    const squares: Array<{ x: number; y: number }> = [];
    const gridWidth = 20;  // Grid is 20 wide
    const gridHeight = 15; // Grid is 15 tall (not 20!)
    
    console.log(`🎯 Generating ${count} random squares on ${gridWidth}x${gridHeight} grid`);
    
    for (let i = 0; i < count; i++) {
      const square = {
        x: Math.floor(Math.random() * gridWidth),
        y: Math.floor(Math.random() * gridHeight)
      };
      squares.push(square);
      console.log(`  Square ${i + 1}: (${square.x}, ${square.y})`);
    }
    
    return squares;
  }

  // In src/services/firestoreService.ts, update createFireTerrain:
  static async createFireTerrain(
    sessionId: string,
    actionId: string,
    centerPosition: { x: number; y: number }
  ): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return;

    const action = session.pendingActions?.find(a => a.id === actionId);
    if (!action) return;

    // Calculate affected squares in 15ft radius (3 squares) - UPDATED RADIUS
    const affectedSquares: Array<{ x: number; y: number }> = [];
    const radius = 3; // 15ft = 3 squares
    
    for (let x = centerPosition.x - radius; x <= centerPosition.x + radius; x++) {
      for (let y = centerPosition.y - radius; y <= centerPosition.y + radius; y++) {
        const distance = Math.sqrt(Math.pow(x - centerPosition.x, 2) + Math.pow(y - centerPosition.y, 2));
        if (distance <= radius) {
          affectedSquares.push({ x, y });
        }
      }
    }

    // Mark action as resolved and store terrain data
    const updatedActions = session.pendingActions?.map(a =>
      a.id === actionId 
        ? { 
            ...a, 
            resolved: true, 
            damageApplied: true,
            terrainCenter: centerPosition,
            affectedSquares 
          }
        : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: updatedActions,
      // Store active fire terrain WITH DURATION TRACKING
      fireTerrainZones: arrayUnion({
        id: `fire_terrain_${Date.now()}`,
        center: centerPosition,
        radius: 15, // Updated to 15ft
        affectedSquares,
        damagePerTurn: 5,
        duration: 3, // 3 rounds
        turnsRemaining: 3,
        createdBy: action.playerId,
        createdAt: Date.now(),
        createdOnRound: session.combatState?.round || 1
      }),
      updatedAt: serverTimestamp()
    });
  }

  // Update createIceWall similarly:
  static async createIceWall(
    sessionId: string,
    actionId: string,
    wallData: {
      type: 'row' | 'column';
      index: number;
      squares: Array<{ x: number; y: number }>;
    }
  ): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return;

    const action = session.pendingActions?.find(a => a.id === actionId);
    if (!action) return;

    // Mark action as resolved and store wall data
    const updatedActions = session.pendingActions?.map(a =>
      a.id === actionId 
        ? { 
            ...a, 
            resolved: true, 
            damageApplied: true,
            wallType: wallData.type,
            wallIndex: wallData.index,
            wallSquares: wallData.squares
          }
        : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: updatedActions,
      // Store active ice walls WITH DURATION TRACKING
      iceWalls: arrayUnion({
        id: `ice_wall_${Date.now()}`,
        type: wallData.type,
        index: wallData.index,
        squares: wallData.squares,
        duration: 3, // 3 rounds
        turnsRemaining: 3,
        createdBy: action.playerId,
        createdAt: Date.now(),
        createdOnRound: session.combatState?.round || 1
      }),
      updatedAt: serverTimestamp()
    });
  }

  // In src/services/firestoreService.ts, replace the applyLightBlindEffects function with:
  static async createLightHighlights(
    sessionId: string,
    actionId: string
  ): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return;

    const action = session.pendingActions?.find(a => a.id === actionId);
    if (!action) return;

    // Generate 20 random squares
    const affectedSquares = this.generateRandomSquares(20);

    // Mark action as resolved
    const updatedActions = session.pendingActions?.map(a =>
      a.id === actionId 
        ? { 
            ...a, 
            resolved: true, 
            damageApplied: true,
            affectedSquares
          }
        : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: updatedActions,
      // Store active light highlights with turn tracking
      lightBlindEffects: arrayUnion({
        id: `light_highlight_${Date.now()}`,
        affectedSquares,
        duration: 3, // 3 rounds
        turnsRemaining: 3,
        createdBy: action.playerId,
        createdAt: Date.now(),
        createdOnRound: session.combatState?.round || 1
      }),
      updatedAt: serverTimestamp()
    });

    console.log(`Light Genesis: Highlighted ${affectedSquares.length} random squares for 3 rounds`);
  }

  static async cleanupExpiredTerrain(sessionId: string): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return;

    const currentRound = session.combatState?.round || 1;
    let needsUpdate = false;
    const updates: any = {};

    console.log(`🔍 Checking terrain cleanup at round ${currentRound}`);

    // Clean up fire terrain
    if (session.fireTerrainZones) {
      const beforeCount = session.fireTerrainZones.length;
      const activeFire = session.fireTerrainZones.filter((zone: any) => {
        const roundsElapsed = currentRound - (zone.createdOnRound || 1);
        const shouldKeep = roundsElapsed < 3;
        console.log(`🔥 Fire terrain ${zone.id}: created round ${zone.createdOnRound}, elapsed ${roundsElapsed}, keep: ${shouldKeep}`);
        return shouldKeep;
      });
      if (activeFire.length !== beforeCount) {
        updates.fireTerrainZones = activeFire;
        needsUpdate = true;
        console.log(`🔥 Removed ${beforeCount - activeFire.length} expired fire terrain zones`);
      }
    }

    // Clean up ice walls
    if (session.iceWalls) {
      const beforeCount = session.iceWalls.length;
      const activeIce = session.iceWalls.filter((wall: any) => {
        const roundsElapsed = currentRound - (wall.createdOnRound || 1);
        const shouldKeep = roundsElapsed < 3;
        console.log(`🧊 Ice wall ${wall.id}: created round ${wall.createdOnRound}, elapsed ${roundsElapsed}, keep: ${shouldKeep}`);
        return shouldKeep;
      });
      if (activeIce.length !== beforeCount) {
        updates.iceWalls = activeIce;
        needsUpdate = true;
        console.log(`🧊 Removed ${beforeCount - activeIce.length} expired ice walls`);
      }
    }

    // Clean up light effects
    if (session.lightBlindEffects) {
      const beforeCount = session.lightBlindEffects.length;
      const activeLight = session.lightBlindEffects.filter((effect: any) => {
        const roundsElapsed = currentRound - (effect.createdOnRound || 1);
        const shouldKeep = roundsElapsed < 3;
        console.log(`⚡ Light effect ${effect.id}: created round ${effect.createdOnRound}, elapsed ${roundsElapsed}, keep: ${shouldKeep}`);
        return shouldKeep;
      });
      if (activeLight.length !== beforeCount) {
        updates.lightBlindEffects = activeLight;
        needsUpdate = true;
        console.log(`⚡ Removed ${beforeCount - activeLight.length} expired light effects`);
      }
    }

    if (needsUpdate) {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        ...updates,
        updatedAt: serverTimestamp()
      });
      console.log('🧹 Successfully cleaned up expired terrain effects');
    } else {
      console.log('✅ No terrain effects needed cleanup');
    }
  }

  // Also add this helper function to manually verify terrain effects status:
  static logTerrainEffectsStatus(session: any): void {
    const currentRound = session?.combatState?.round || 1;
    
    console.log(`\n📊 TERRAIN STATUS REPORT - Round ${currentRound}`);
    console.log('='.repeat(50));
    
    if (session?.fireTerrainZones?.length > 0) {
      console.log('🔥 FIRE TERRAIN:');
      session.fireTerrainZones.forEach((zone: any, index: number) => {
        const elapsed = currentRound - (zone.createdOnRound || 1);
        const remaining = Math.max(0, 3 - elapsed);
        console.log(`  ${index + 1}. ${zone.id} - Created: Round ${zone.createdOnRound}, Remaining: ${remaining} rounds`);
      });
    } else {
      console.log('🔥 FIRE TERRAIN: None active');
    }
    
    if (session?.iceWalls?.length > 0) {
      console.log('🧊 ICE WALLS:');
      session.iceWalls.forEach((wall: any, index: number) => {
        const elapsed = currentRound - (wall.createdOnRound || 1);
        const remaining = Math.max(0, 3 - elapsed);
        console.log(`  ${index + 1}. ${wall.id} - Created: Round ${wall.createdOnRound}, Remaining: ${remaining} rounds`);
      });
    } else {
      console.log('🧊 ICE WALLS: None active');
    }
    
    if (session?.lightBlindEffects?.length > 0) {
      console.log('⚡ LIGHT EFFECTS:');
      session.lightBlindEffects.forEach((effect: any, index: number) => {
        const elapsed = currentRound - (effect.createdOnRound || 1);
        const remaining = Math.max(0, 3 - elapsed);
        console.log(`  ${index + 1}. ${effect.id} - Created: Round ${effect.createdOnRound}, Remaining: ${remaining} rounds`);
      });
    } else {
      console.log('⚡ LIGHT EFFECTS: None active');
    }
    
    console.log('='.repeat(50));
  }

  static async createTurretPlacementAction(
    sessionId: string,
    payload: {
      playerId: string;
      playerPosition: { x: number; y: number };
      turretName: string;
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');
    
    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    if (!playerToken) throw new Error('Player token not found');

    const action: GMCombatAction = {
      id: `turret-placement-${Date.now()}`,
      type: 'turret_placement',
      playerId: payload.playerId,
      sourcePosition: payload.playerPosition,
      acRoll: 0, // Not used for placement
      range: 5, // 5ft placement radius
      timestamp: new Date(),
      resolved: false,
      hit: true, // Always succeeds
      needsDamageInput: false,
      damageApplied: false,
      playerName: playerToken.name,
      abilityName: `Deploy ${payload.turretName}`,
      targetIds: [], // No specific targets
      targetNames: [],
      // Custom data for turret placement
      turretData: {
        name: payload.turretName,
        hp: 10,
        maxHp: 10,
        type: 'npc',
        color: '#8B4513',
        size: 1
      }
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });

    return action;
  }
  // Clean up expired protection effects
  static async cleanupExpiredProtectionEffects(sessionId: string): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return;

    const currentRound = session.combatState?.round || 1;
    let needsUpdate = false;
    const updates: any = {};

    if (session.activeProtectionEffects) {
      const beforeCount = session.activeProtectionEffects.length;
      const activeProtections = session.activeProtectionEffects.filter((effect: any) => {
        const roundsElapsed = currentRound - (effect.activatedOnRound || 1);
        const shouldKeep = roundsElapsed < 2;
        return shouldKeep;
      });
      
      if (activeProtections.length !== beforeCount) {
        updates.activeProtectionEffects = activeProtections;
        needsUpdate = true;
      }
    }

    if (needsUpdate) {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    }
  }
  // Create Leader's Sacrifice protection action
  static async createLeadersSacrificePAction(
    sessionId: string,
    payload: {
      playerId: string;
      playerName: string;
      currentRound: number;
    }
  ): Promise<GMCombatAction> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');
    
    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    if (!playerToken) throw new Error('Player token not found');

    const action: GMCombatAction = {
      id: `leaders-sacrifice-${Date.now()}`,
      type: 'ability',
      playerId: payload.playerId,
      sourcePosition: playerToken.position,
      acRoll: 0,
      range: 0,
      timestamp: new Date(),
      resolved: false,
      hit: true,
      needsDamageInput: false,
      damageApplied: false,
      playerName: payload.playerName,
      abilityName: "Leader's Sacrifice",
      targetIds: [],
      targetNames: [],
      protectionData: {
        protectorName: payload.playerName,
        activatedOnRound: payload.currentRound,
        duration: 2,
        remainingRounds: 2,
        protectedAlly: 'TBD - GM to assign manually',
        description: 'Gustave redirects damage from protected ally to himself for 2 rounds'
      }
    };

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      activeProtectionEffects: arrayUnion({
        id: action.id,
        protectorId: payload.playerId,
        protectorName: payload.playerName,
        activatedOnRound: payload.currentRound,
        remainingRounds: 2,
        protectedAlly: 'TBD - Call out to GM',
        type: 'leaders_sacrifice'
      }),
      updatedAt: serverTimestamp()
    });

    return action;
  }

  // src/services/firestoreService.ts

  // Add these methods to the FirestoreService class

  static async updateTargetingState(
    sessionId: string,
    targetingState: { selectedEnemyId: string; playerId: string }
  ): Promise<void> {
    const sessionRef = doc(db, 'battleSessions', sessionId);  // Changed from 'sessions' to 'battleSessions'
    await updateDoc(sessionRef, {
      targetingState,
      updatedAt: serverTimestamp()
    });
  }

  static subscribeToTargetingState(
    sessionId: string,
    callback: (targetingState: any) => void
  ): () => void {
    const sessionRef = doc(db, 'battleSessions', sessionId);  // Changed from 'sessions' to 'battleSessions'
    
    const unsubscribe = onSnapshot(sessionRef, (snapshot) => {
      const data = snapshot.data();
      callback(data?.targetingState || null);
    });
    
    return unsubscribe;
  }

  static async clearTargetingState(sessionId: string): Promise<void> {
    const sessionRef = doc(db, 'battleSessions', sessionId);  // Changed from 'sessions' to 'battleSessions'
    await updateDoc(sessionRef, {
      targetingState: deleteField(),
      updatedAt: serverTimestamp()
    });
  }

  // Create self destruct action - destroys turret and damages nearby enemies
  static async createSelfDestructAction(
    sessionId: string,
    payload: {
      playerId: string;
      turretId: string;
      turretPosition: { x: number; y: number };
    }
  ): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session) throw new Error('Session not found');
    
    const turret = session.tokens[payload.turretId];
    if (!turret) throw new Error('Turret not found');
    
    // Find enemies within 10ft of turret
    const enemies = Object.values(session.tokens).filter(token => 
      token.type === 'enemy' && 
      (token.hp || 0) > 0
    );
    
    const calculateDistance = (pos1: { x: number; y: number }, pos2: { x: number; y: number }): number => {
      const dx = Math.abs(pos1.x - pos2.x);
      const dy = Math.abs(pos1.y - pos2.y);
      return Math.max(dx, dy) * 5;
    };
    
    const enemiesInRange = enemies.filter(enemy => 
      calculateDistance(payload.turretPosition, enemy.position) <= 10
    );
    
    const playerToken = Object.values(session.tokens).find(t => t.characterId === payload.playerId);
    
    // Remove the turret immediately
    const updatedTokens = { ...session.tokens };
    delete updatedTokens[payload.turretId];
    
    // If there are enemies in range, create AoE damage action
    if (enemiesInRange.length > 0) {
      const action: GMCombatAction = {
        id: `self-destruct-${Date.now()}`,
        type: 'ability',
        playerId: payload.playerId,
        sourcePosition: payload.turretPosition,
        acRoll: 999, // Auto-hit
        range: 10,
        timestamp: new Date(),
        resolved: false,
        hit: true,
        needsDamageInput: true,
        damageApplied: false,
        playerName: playerToken?.name || 'Gustave',
        abilityName: 'Turret Self Destruct (2d6 fire)',
        targetIds: enemiesInRange.map(e => e.id),
        targetNames: enemiesInRange.map(e => e.name)
      };
      
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        tokens: updatedTokens,
        pendingActions: arrayUnion(action),
        updatedAt: serverTimestamp()
      });
    } else {
      // No enemies in range, just remove turret
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        tokens: updatedTokens,
        updatedAt: serverTimestamp()
      });
    }
  }


  static async dismissMissAction(sessionId: string, actionId: string) {
    const session = await this.getBattleSession(sessionId);
    if (!session || !session.pendingActions) return;

    const updatedActions = session.pendingActions.map(a =>
      a.id === actionId ? { ...a, resolved: true } : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, { pendingActions: updatedActions, updatedAt: serverTimestamp() });
  }

  // Legacy support (used by useCombat)
  static async addCombatAction(sessionId: string, action: CombatAction) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      pendingActions: arrayUnion(action),
      updatedAt: serverTimestamp()
    });
  }

  static async resolveCombatAction(sessionId: string, actionId: string) {
    const session = await this.getBattleSession(sessionId);
    if (!session || !session.pendingActions) return;

    const updatedActions = session.pendingActions.map(a =>
      a.id === actionId ? { ...a, resolved: true } : a
    );

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, { pendingActions: updatedActions, updatedAt: serverTimestamp() });
  }

  static async updateEnemyHP(sessionId: string, enemyId: string, currentHP: number) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      [`enemyHP.${enemyId}.current`]: Math.max(0, currentHP),
      updatedAt: serverTimestamp()
    });
    if (currentHP <= 0) await this.removeToken(sessionId, enemyId);
  }

  static async updateTokenPosition(sessionId: string, tokenId: string, position: Position) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, { [`tokens.${tokenId}.position`]: position, updatedAt: serverTimestamp() });
  }

  // ========== Combat state ==========
  static async startCombat(sessionId: string, initiativeOrder: InitiativeEntry[]) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      'combatState.isActive': true,
      'combatState.phase': 'combat',
      'combatState.round': 1,
      'combatState.currentTurn': initiativeOrder[0]?.id ?? '',
      'combatState.turnOrder': initiativeOrder.map(e => e.id),
      'combatState.initiativeOrder': initiativeOrder,
      updatedAt: serverTimestamp()
    });
  }

  // UPDATE: Enhanced nextTurn method to include buff/vanish processing
  static async nextTurn(sessionId: string) {
    const session = await this.getBattleSession(sessionId);
    if (!session?.combatState) return;

    const { turnOrder, currentTurn, round } = session.combatState;
    const cur = turnOrder.indexOf(currentTurn);
    const nextIndex = cur + 1 >= turnOrder.length ? 0 : cur + 1;
    const nextRound = cur + 1 >= turnOrder.length ? round + 1 : round;
    const nextTurn = turnOrder[nextIndex];

    if (nextTurn === 'lune') {
      await StatusEffectService.processBurnDamage(sessionId, nextTurn);
    }
    if (nextIndex === 0) {
      await StatusEffectService.updateStatusEffectDurations(sessionId);
    }

    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      'combatState.currentTurn': nextTurn,
      'combatState.round': nextRound,
      ...(nextIndex === 0 && {
        'combatState.initiativeOrder': session.combatState.initiativeOrder.map(e => ({
          ...e,
          hasActed: false
        }))
      }),
      updatedAt: serverTimestamp()
    });

    // Process terrain effects, protection effects, buffs, and vanished enemies
    await this.cleanupExpiredSummons(sessionId);
    await this.cleanupExpiredTerrain(sessionId);
    await this.cleanupExpiredProtectionEffects(sessionId);
    await this.processBuffsAndVanishedEnemies(sessionId); // NEW

    console.log('Turn advanced and all effects processed');
  }
  static async setInitiativeOrder(sessionId: string, initiativeOrder: InitiativeEntry[]) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      'combatState.initiativeOrder': initiativeOrder,
      'combatState.turnOrder': initiativeOrder.map(e => e.id),
      'combatState.currentTurn': initiativeOrder[0]?.id ?? '',
      updatedAt: serverTimestamp()
    });
  }

  // NEW: Helper method to check if a character has active buffs
  static async getActiveBuffsForCharacter(sessionId: string, characterId: string): Promise<ActiveBuff[]> {
    const session = await this.getBattleSession(sessionId);
    if (!session?.activeBuffs) return [];

    return session.activeBuffs.filter((buff: ActiveBuff) => 
      buff.targetId === characterId || 
      Object.values(session.tokens).find(t => t.characterId === characterId)?.id === buff.targetId
    );
  }

  // NEW: Helper method to get vanished enemies info
  static async getVanishedEnemiesInfo(sessionId: string): Promise<VanishedEnemy[]> {
    const session = await this.getBattleSession(sessionId);
    return session?.vanishedEnemies || [];
  }

  // ========== Movement ==========
  static calculateMovementDistance(from: Position, to: Position): number {
    const dx = Math.abs(to.x - from.x);
    const dy = Math.abs(to.y - from.y);
    const diagonals = Math.min(dx, dy);
    const straight = Math.max(dx, dy) - diagonals;
    return diagonals * 5 + straight * 5;
  }

  static async validateAndMoveToken(
    sessionId: string,
    tokenId: string,
    newPosition: Position,
    characterId?: string
  ): Promise<boolean> {
    const session = await this.getBattleSession(sessionId);
    if (!session) return false;

    const token = session.tokens[tokenId];
    if (!token) return false;

    const distance = this.calculateMovementDistance(token.position, newPosition);

    let maxMovement = 30;
    if (characterId) {
      const c = await this.getCharacter(characterId);
      if (c && c.name.toLowerCase() === 'maelle' && c.stance === 'agile') maxMovement = 60;
    }

    if (distance > maxMovement) {
      console.log(`Move ${distance}ft exceeds ${maxMovement}ft`);
      return false;
    }

    await this.updateTokenPosition(sessionId, tokenId, newPosition);
    return true;
  }

  // ========== Ranging / Targeting ==========
  static calculateRange(from: Position, to: Position): number {
    const dx = Math.abs(to.x - from.x);
    const dy = Math.abs(to.y - from.y);
    return Math.max(dx, dy) * 5;
  }

  static getValidTargets(
    sourcePosition: Position,
    tokens: BattleToken[],
    range: number,
    targetType: 'enemy' | 'ally' | 'any' = 'any'
  ): string[] {
    return tokens
      .filter(t => {
        const dist = this.calculateRange(sourcePosition, t.position);
        const within = dist <= range;
        let ok = true;
        if (targetType === 'enemy') ok = t.type === 'enemy';
        else if (targetType === 'ally') ok = t.type === 'player';
        return within && ok;
      })
      .map(t => t.id);
  }

  // ========== Sessions ==========
  static async getBattleSession(sessionId: string): Promise<BattleSession | null> {
    try {
      const ref = doc(db, 'battleSessions', sessionId);
      const snap = await getDoc(ref);
      if (!snap.exists()) return null;
      const data = snap.data() as BattleSessionDoc;
      return {
        id: snap.id,
        ...data,
        createdAt: data.createdAt?.toDate() ?? new Date(),
        updatedAt: data.updatedAt?.toDate() ?? new Date()
      };
    } catch (e) {
      console.error('getBattleSession error:', e);
      return null;
    }
  }

  // Reset Lune's ultimate on combat end (instead of long rest)
  static async resetLuneUltimate(sessionId: string): Promise<void> {
    try {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        'luneElementalGenesisUsed': false, // Reset ultimate cooldown
        updatedAt: serverTimestamp()
      });
      console.log('Lune ultimate cooldown reset');
    } catch (error) {
      console.error('Failed to reset Lune ultimate:', error);
      throw error;
    }
  }

  // Also update the existing endCombat method to include Lune reset:
  static async endCombat(sessionId: string) {
    const ref = doc(db, 'battleSessions', sessionId);
    await updateDoc(ref, {
      'combatState.isActive': false,
      'combatState.phase': 'ended',
      'combatState.currentTurn': '',
      pendingActions: [],
      'tokens.token-maelle.phantomStrikeUsed': false,
      'luneElementalGenesisUsed': false, // Reset Lune's ultimate on combat end
      updatedAt: serverTimestamp()
    });
  }

  static async createDefaultPlayerTokens(sessionId: string): Promise<void> {
    console.log('🎭 Creating default player tokens...');
    
    const defaultPlayerTokens = {
      'player-maelle': {
        id: 'player-maelle',
        characterId: 'maelle',
        name: 'Maelle',
        position: { x: 2, y: 12 }, // Bottom left area
        type: 'player' as const,
        hp: 28,
        maxHp: 28,
        ac: 15,
        size: 1,
        color: '#4f46e5' // Royal blue
      },
      'player-gustave': {
        id: 'player-gustave',
        characterId: 'gustave',
        name: 'Gustave',
        position: { x: 4, y: 12 }, // Bottom left area
        type: 'player' as const,
        hp: 32,
        maxHp: 32,
        ac: 16,
        size: 1,
        color: '#dc2626' // Red
      },
      'player-lune': {
        id: 'player-lune',
        characterId: 'lune',
        name: 'Lune',
        position: { x: 6, y: 12 }, // Bottom left area
        type: 'player' as const,
        hp: 22,
        maxHp: 22,
        ac: 13,
        size: 1,
        color: '#7c3aed' // Purple
      },
      'player-sciel': {
        id: 'player-sciel',
        characterId: 'sciel',
        name: 'Sciel',
        position: { x: 8, y: 12 }, // Bottom left area
        type: 'player' as const,
        hp: 26,
        maxHp: 26,
        ac: 14,
        size: 1,
        color: '#059669' // Green
      }
    };

    try {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, {
        tokens: defaultPlayerTokens,
        updatedAt: serverTimestamp()
      });
      
      console.log('✅ Default player tokens created successfully');
    } catch (error) {
      console.error('❌ Failed to create default player tokens:', error);
      throw error;
    }
  }



  static subscribeToBattleSession(
    sessionId: string,
    cb: (session: BattleSession | null) => void
  ) {
    const ref = doc(db, 'battleSessions', sessionId);
    return onSnapshot(
      ref,
      snap => {
        if (!snap.exists()) return cb(null);
        const data = snap.data() as BattleSessionDoc;
        cb({
          id: snap.id,
          ...data,
          createdAt: data.createdAt?.toDate() ?? new Date(),
          updatedAt: data.updatedAt?.toDate() ?? new Date()
        });
      },
      err => {
        console.error('Battle session listener error:', err);
        cb(null);
      }
    );
  }

  static subscribeToCharacter(
    characterId: string,
    callback: (character: Character | null) => void
  ): () => void {
    const characterRef = doc(db, 'characters', characterId);

    return onSnapshot(characterRef, (doc) => {
      if (!doc.exists()) {
        callback(null);
        return;
      }

      const data = doc.data() as CharacterDoc;
      
      const character: Character = {
        id: characterId,
        name: data.name,
        role: data.role,
        stats: data.stats,
        currentHP: data.currentHP,
        maxHP: data.maxHP,
        abilities: data.abilities,
        stance: data.stance,
        charges: data.charges,
        maxCharges: data.maxCharges,
        level: data.level,
        portraitUrl: data.portraitUrl,
        backgroundColor: data.backgroundColor,
        inventory: data.inventory || [],
        gold: data.gold || 0,
        
        // NEW: Include combat state with proper date conversion
        combatState: data.combatState ? {
          // Start with defaults to ensure all properties exist
          ...CombatStateHelpers.createDefaultCombatState(),
          // Override with saved values
          ...data.combatState,
          lastUpdated: data.combatState.lastUpdated?.toDate() || new Date(),
          lastSyncedAt: data.combatState.lastSyncedAt?.toDate() || new Date()
        } : CombatStateHelpers.createDefaultCombatState(),
        afterimageStacks: data.afterimageStacks,
        maxAfterimageStacks: data.maxAfterimageStacks,
        phantomStrikeUsed: data.phantomStrikeUsed
      };

      callback(character);
    });
  }

  // ---- Add below other helpers in FirestoreService ----
  static getNPCMaxHP(npcKey: 'the-child' | 'farmhand', level: number): number {
    const childHP = [14, 25, 35];
    const farmhandHP = [30, 40, 50];
    return npcKey === 'the-child'
      ? (childHP[level - 1] ?? childHP[0])
      : (farmhandHP[level - 1] ?? farmhandHP[0]);
  }

  /**
   * After npcLevels change, sync all matching NPC tokens' maxHp (and clamp / heal hp).
   * We match either by token.id, token.name, or a known controller mapping.
   */
  static async syncNPCLevelsToTokens(
    sessionId: string,
    levels: { newRecruit: number; farmhand: number }
  ): Promise<void> {
    const session = await this.getBattleSession(sessionId);
    if (!session?.tokens) return;

    const updates: Record<string, any> = {};

    // Build easy matchers
    const isChild = (t: any) =>
      t?.type === 'npc' &&
      (
        t.id === 'the-child' ||
        /child/i.test(t.name ?? '') ||
        t.controllerId === 'the-child' ||
        t.controlledBy === 'maelle' || t.controlledBy === 'gustave'
      );

    const isFarmhand = (t: any) =>
      t?.type === 'npc' &&
      (t.id === 'farmhand' || /farmhand/i.test(t.name ?? '') || t.controlledBy === 'sciel');

    for (const [tokenId, token] of Object.entries(session.tokens)) {
      let npcKey: 'the-child' | 'farmhand' | null = null;
      let level = 1;

      if (isChild(token)) {
        npcKey = 'the-child';
        level = levels.newRecruit || 1;
      } else if (isFarmhand(token)) {
        npcKey = 'farmhand';
        level = levels.farmhand || 1;
      }

      if (!npcKey) continue;

      const newMax = this.getNPCMaxHP(npcKey, level);
      const oldMax = (token as any).maxHp ?? newMax;
      const oldHP  = (token as any).hp ?? newMax;

      // If leveling up, set to full. If leveling down, clamp.
      const newHP = newMax > oldMax ? newMax : Math.min(oldHP, newMax);

      updates[`tokens.${tokenId}.maxHp`] = newMax;
      updates[`tokens.${tokenId}.hp`] = newHP;
      updates[`tokens.${tokenId}.npcLevel`] = level;
    }

    if (Object.keys(updates).length > 0) {
      const ref = doc(db, 'battleSessions', sessionId);
      await updateDoc(ref, { ...updates, updatedAt: serverTimestamp() });
      console.log('✅ Synced NPC token HP/MaxHP with new levels');
    }
  }

  // ========== Sample Data ==========
  static async initializeSampleData(): Promise<void> {
    console.log('📊 Initializing sample character data with combat state...');

    const sampleCharacters: CharacterDoc[] = [
      {
        name: 'Maelle',
        role: 'Phantom Blade Duelist',
        stats: { str: 12, dex: 16, con: 13, int: 10, wis: 11, cha: 14 },
        currentHP: 28,
        maxHP: 28,
        stance: 'offensive',
        charges: 0,
        maxCharges: 5,
        level: 3,
        portraitUrl: '/portraits/maelle.jpg',
        backgroundColor: '#8B5A2B',
        inventory: [],
        gold: 150,
        combatState: {
          ...CombatStateHelpers.createDefaultCombatState(),
          lastUpdated: serverTimestamp(),
          lastSyncedAt: serverTimestamp()
        },
        afterimageStacks: 0,
        maxAfterimageStacks: 5,
        phantomStrikeUsed: false,
        abilities: [
          {
            id: 'fencers-slash',
            name: "Fencer's Slash",
            description: 'A precise sword attack that gains +1 afterimage stack.',
            type: 'action',
            damage: '1d8 + DEX',
            range: '5 feet'
          },
          {
            id: 'flourish-chain',
            name: 'Flourish Chain',
            description: 'Consume 2 afterimage stacks for an additional attack.',
            type: 'bonus_action',
            damage: '1d8 + DEX',
            range: '5 feet'
          },
          {
            id: 'dazzling-feint',
            name: 'Dazzling Feint',
            description: 'Consume 1 stack to gain advantage on next attack.',
            type: 'bonus_action',
            effect: 'Advantage on next attack',
            range: 'Self'
          },
          {
            id: 'phantom-strike',
            name: 'Phantom Strike',
            description: 'Ultimate: Consume 3+ stacks for devastating combo attack.',
            type: 'action',
            damage: 'Special',
            range: '5 feet'
          }
        ],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      {
        name: 'Gustave',
        role: 'Engineering Vanguard',
        stats: { str: 16, dex: 12, con: 15, int: 14, wis: 11, cha: 10 },
        currentHP: 34,
        maxHP: 34,
        charges: 0,
        maxCharges: 3,
        level: 3,
        portraitUrl: '/portraits/gustave.jpg',
        backgroundColor: '#2D4A3E',
        inventory: [],
        gold: 200,
        combatState: {
          ...CombatStateHelpers.createDefaultCombatState(),
          lastUpdated: serverTimestamp(),
          lastSyncedAt: serverTimestamp()
        },
        abilities: [
          {
            id: 'sword-slash',
            name: 'Sword Slash',
            description: 'Basic melee attack with sword.',
            type: 'action',
            damage: '1d8 + STR',
            range: '5 feet'
          },
          {
            id: 'prosthetic-strike',
            name: 'Prosthetic Strike',
            description: 'Enhanced strike using prosthetic arm. Consumes 1 Overload charge.',
            type: 'action',
            damage: '1d8 + STR + 1d6 (overload)',
            range: '5 feet',
            costsCharges: 1
          },
          {
            id: 'deploy-turret',
            name: 'Deploy Turret',
            description: 'Deploy a defensive turret. Consumes 2 Overload charges.',
            type: 'action',
            effect: 'Deploys turret with 15 HP, AC 12',
            range: '10 feet',
            costsCharges: 2
          }
        ],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      {
        name: 'Lune',
        role: 'Elemental Scholar',
        stats: { str: 10, dex: 12, con: 13, int: 16, wis: 14, cha: 11 },
        currentHP: 24,
        maxHP: 24,
        charges: 0,
        maxCharges: 4,
        level: 3,
        portraitUrl: '/portraits/lune.jpg',
        backgroundColor: '#4A5568',
        inventory: [],
        gold: 125,
        combatState: {
          ...CombatStateHelpers.createDefaultCombatState(),
          lastUpdated: serverTimestamp(),
          lastSyncedAt: serverTimestamp()
        },
        abilities: [
          {
            id: 'elemental-bolt',
            name: 'Elemental Bolt',
            description: 'Ranged elemental attack. Roll 1d4 for element type.',
            type: 'action',
            damage: '1d8 + INT',
            range: '60 feet'
          },
          {
            id: 'elemental-strike',
            name: 'Elemental Strike',
            description: 'Melee attack that applies elemental stain.',
            type: 'action',
            damage: '1d6 + INT',
            range: '5 feet'
          },
          {
            id: 'twin-catalyst',
            name: 'Twin Catalyst',
            description: 'Consume 2 stains to cast two bolts.',
            type: 'action',
            damage: '2 × (1d8 + INT)',
            range: '60 feet'
          }
        ],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      },
      {
        name: 'Sciel',
        role: 'Tarot Mystic',
        stats: { str: 13, dex: 14, con: 12, int: 11, wis: 15, cha: 16 },
        currentHP: 26,
        maxHP: 26,
        charges: 0,
        maxCharges: 4,
        level: 3,
        portraitUrl: '/portraits/sciel.jpg',
        backgroundColor: '#553C7B',
        inventory: [],
        gold: 175,
        combatState: {
          ...CombatStateHelpers.createDefaultCombatState(),
          lastUpdated: serverTimestamp(),
          lastSyncedAt: serverTimestamp()
        },
        abilities: [
          {
            id: 'card-toss',
            name: 'Card Toss',
            description: 'Throw a tarot card as a ranged attack.',
            type: 'action',
            damage: '1d6 + CHA',
            range: '30 feet'
          },
          {
            id: 'guiding-cards',
            name: 'Guiding Cards',
            description: 'Grant advantage to ally. Builds Foretell stacks.',
            type: 'bonus_action',
            effect: 'Ally gains advantage',
            range: '30 feet'
          },
          {
            id: 'moonlit-ward',
            name: 'Moonlit Ward',
            description: 'Protective barrier using Foretell energy.',
            type: 'reaction',
            effect: '+2 AC until end of turn',
            range: 'Self or ally'
          }
        ],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }
    ];

    const promises = sampleCharacters.map(async (characterData, index) => {
      const characterId = ['maelle', 'gustave', 'lune', 'sciel'][index];
      const characterRef = doc(db, 'characters', characterId);
      
      try {
        await setDoc(characterRef, characterData);
        console.log(`✅ Initialized character: ${characterData.name} with combat state`);
      } catch (error) {
        console.error(`❌ Error initializing ${characterData.name}:`, error);
      }
    });

    await Promise.all(promises);
    console.log('✅ All sample characters initialized with combat state support');
  }
}