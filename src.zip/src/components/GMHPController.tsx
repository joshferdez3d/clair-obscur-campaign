// GMHPController.tsx - Final Fix for All Black Text

import React, { useState } from 'react';
import { Heart, Plus, Minus, Activity, Settings } from 'lucide-react';

interface GMHPControllerProps {
  characterId: string;
  characterName: string;
  currentHP: number;
  maxHP: number;
  isLoading: boolean;
  onHPChange: (newHP: number) => Promise<void>;
  onMaxHPChange: (newMaxHP: number) => Promise<void>;
}

export function GMHPController({
  characterId,
  characterName,
  currentHP,
  maxHP,
  isLoading,
  onHPChange,
  onMaxHPChange,
}: GMHPControllerProps) {
  const [damageAmount, setDamageAmount] = useState<string>('');
  const [healAmount, setHealAmount] = useState<string>('');
  const [targetHP, setTargetHP] = useState<string>('');
  const [targetMaxHP, setTargetMaxHP] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'current' | 'max'>('current');

  const hpPercentage = maxHP > 0 ? (currentHP / maxHP) * 100 : 0;

  const getHPBarColor = () => {
    if (currentHP <= 0) return 'bg-red-600';
    if (hpPercentage <= 25) return 'bg-red-500';
    if (hpPercentage <= 50) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getHPTextColor = () => {
    if (currentHP <= 0) return 'text-red-200';
    if (hpPercentage <= 25) return 'text-red-200';
    if (hpPercentage <= 50) return 'text-yellow-200';
    return 'text-green-200';
  };

  const handleDamage = async () => {
    const damage = parseInt(damageAmount);
    if (isNaN(damage) || damage <= 0) return;
    
    const newHP = Math.max(0, currentHP - damage);
    await onHPChange(newHP);
    setDamageAmount('');
  };

  const handleHeal = async () => {
    const heal = parseInt(healAmount);
    if (isNaN(heal) || heal <= 0) return;
    
    const newHP = Math.min(maxHP, currentHP + heal);
    await onHPChange(newHP);
    setHealAmount('');
  };

  const handleSetHP = async () => {
    const hp = parseInt(targetHP);
    if (isNaN(hp) || hp < 0 || hp > maxHP) return;
    
    await onHPChange(hp);
    setTargetHP('');
  };

  const handleSetMaxHP = async () => {
    const newMaxHP = parseInt(targetMaxHP);
    if (isNaN(newMaxHP) || newMaxHP <= 0) return;
    
    await onMaxHPChange(newMaxHP);
    setTargetMaxHP('');
  };

  return (
    <div className="bg-clair-dark-800 border border-clair-shadow-600 rounded-lg p-4 min-h-[400px] flex flex-col">
      {/* Character Header */}
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-white">{characterName}</h3>
        <div className="flex items-center gap-2">
          <Heart className="h-4 w-4 text-red-400" />
          <span className={`font-bold ${getHPTextColor()}`}>
            {currentHP} / {maxHP}
          </span>
        </div>
      </div>

      {/* HP Bar */}
      <div className="mb-4">
        <div className="w-full bg-clair-shadow-800 rounded-full h-3 overflow-hidden">
          <div
            className={`h-full transition-all duration-300 ${getHPBarColor()}`}
            style={{ width: `${Math.max(0, Math.min(100, hpPercentage))}%` }}
          />
        </div>
        <div className="text-xs text-gray-300 text-center mt-1">
          {hpPercentage.toFixed(0)}%
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex bg-clair-shadow-700 rounded-lg p-1 mb-4">
        <button
          onClick={() => setActiveTab('current')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'current'
              ? 'bg-clair-dark-700 text-white'
              : 'text-gray-300 hover:text-white'
          }`}
        >
          <Activity className="h-4 w-4" />
          Current HP
        </button>
        <button
          onClick={() => setActiveTab('max')}
          className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
            activeTab === 'max'
              ? 'bg-clair-dark-700 text-white'
              : 'text-gray-300 hover:text-white'
          }`}
        >
          <Settings className="h-4 w-4" />
          Max HP
        </button>
      </div>

      {/* Content Area - Fixed Height */}
      <div className="flex-1 flex flex-col">
        {/* Current HP Tab */}
        {activeTab === 'current' && (
          <div className="space-y-4 flex-1">
            {/* Damage and Heal */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-white">Damage</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={damageAmount}
                    onChange={(e) => setDamageAmount(e.target.value)}
                    placeholder="0"
                    className="flex-1 bg-clair-shadow-700 border border-clair-shadow-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-red-500 placeholder-gray-400"
                    min="0"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleDamage();
                      }
                    }}
                  />
                  <button
                    onClick={handleDamage}
                    disabled={isLoading || !damageAmount || parseInt(damageAmount) <= 0}
                    className="px-3 py-2 bg-red-700 hover:bg-red-800 disabled:bg-red-900 disabled:opacity-50 text-white rounded text-sm font-medium transition-colors flex items-center justify-center"
                    title="Apply Damage"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-white">Heal</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={healAmount}
                    onChange={(e) => setHealAmount(e.target.value)}
                    placeholder="0"
                    className="flex-1 bg-clair-shadow-700 border border-clair-shadow-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-green-500 placeholder-gray-400"
                    min="0"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleHeal();
                      }
                    }}
                  />
                  <button
                    onClick={handleHeal}
                    disabled={isLoading || !healAmount || parseInt(healAmount) <= 0}
                    className="px-3 py-2 bg-green-700 hover:bg-green-800 disabled:bg-green-900 disabled:opacity-50 text-white rounded text-sm font-medium transition-colors flex items-center justify-center"
                    title="Apply Healing"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Set HP */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-white">Set HP</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={targetHP}
                  onChange={(e) => setTargetHP(e.target.value)}
                  placeholder="Enter target HP"
                  className="flex-1 bg-clair-shadow-700 border border-clair-shadow-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-blue-500 placeholder-gray-400"
                  min="0"
                  max={maxHP}
                />
                <button
                  onClick={handleSetHP}
                  disabled={isLoading || !targetHP || parseInt(targetHP) < 0 || parseInt(targetHP) > maxHP}
                  className="px-4 py-2 bg-blue-700 hover:bg-blue-800 disabled:bg-blue-900 disabled:opacity-50 text-white rounded text-sm font-medium transition-colors"
                >
                  {isLoading ? 'Applying...' : 'Apply'}
                </button>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="pt-3 border-t border-clair-shadow-600">
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => onHPChange(maxHP)}
                  disabled={isLoading || currentHP >= maxHP}
                  className="px-2 py-1 bg-green-700 hover:bg-green-800 disabled:bg-green-900 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
                >
                  Full Heal
                </button>
                <button
                  onClick={() => onHPChange(0)}
                  disabled={isLoading || currentHP <= 0}
                  className="px-2 py-1 bg-red-700 hover:bg-red-800 disabled:bg-red-900 disabled:opacity-50 text-white rounded text-xs font-medium transition-colors"
                >
                  Set to 0
                </button>
                <button
                  onClick={() => onHPChange(Math.floor(maxHP / 2))}
                  disabled={isLoading}
                  className="px-2 py-1 bg-yellow-700 hover:bg-yellow-800 text-white rounded text-xs font-medium transition-colors"
                >
                  Half HP
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Max HP Tab */}
        {activeTab === 'max' && (
          <div className="space-y-4 flex-1">
            <div className="bg-clair-shadow-800 border border-clair-shadow-600 rounded-lg p-3">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-white">Current Max HP</span>
                <span className="text-lg font-bold text-white">{maxHP}</span>
              </div>
              
              <div className="space-y-3">
                <label className="block text-sm font-medium text-white">
                  Set New Max HP
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={targetMaxHP}
                    onChange={(e) => setTargetMaxHP(e.target.value)}
                    placeholder="Enter new max HP"
                    className="flex-1 bg-clair-shadow-700 border border-clair-shadow-600 rounded px-3 py-2 text-white text-sm focus:outline-none focus:border-purple-500 placeholder-gray-400"
                    min="1"
                  />
                  <button
                    onClick={handleSetMaxHP}
                    disabled={isLoading || !targetMaxHP || parseInt(targetMaxHP) <= 0}
                    className="px-4 py-2 bg-purple-700 hover:bg-purple-800 disabled:bg-purple-900 disabled:opacity-50 text-white rounded text-sm font-medium transition-colors"
                  >
                    {isLoading ? 'Updating...' : 'Update'}
                  </button>
                </div>
                
                {parseInt(targetMaxHP) > 0 && (
                  <div className="text-xs text-blue-200 bg-blue-900/20 border border-blue-500/30 rounded p-2">
                    <strong className="text-blue-100">Note:</strong> Setting max HP to {targetMaxHP} will also set current HP to {targetMaxHP} (full heal).
                  </div>
                )}
              </div>
            </div>

            {/* Level Up Presets */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-white">Level Up Presets</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setTargetMaxHP((maxHP + 5).toString())}
                  disabled={isLoading}
                  className="px-3 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded text-sm font-medium transition-colors"
                >
                  +5 HP
                </button>
                <button
                  onClick={() => setTargetMaxHP((maxHP + 8).toString())}
                  disabled={isLoading}
                  className="px-3 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded text-sm font-medium transition-colors"
                >
                  +8 HP
                </button>
                <button
                  onClick={() => setTargetMaxHP((maxHP + 10).toString())}
                  disabled={isLoading}
                  className="px-3 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded text-sm font-medium transition-colors"
                >
                  +10 HP
                </button>
                <button
                  onClick={() => setTargetMaxHP((maxHP + 12).toString())}
                  disabled={isLoading}
                  className="px-3 py-2 bg-indigo-700 hover:bg-indigo-800 text-white rounded text-sm font-medium transition-colors"
                >
                  +12 HP
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Status Indicators - Fixed Position at Bottom */}
      <div className="mt-4 h-12 flex items-end">
        {currentHP <= 0 && (
          <div className="w-full p-2 bg-red-900 border border-red-500 rounded text-center">
            <p className="text-red-200 text-sm font-bold">UNCONSCIOUS</p>
          </div>
        )}
        {currentHP > 0 && currentHP <= maxHP * 0.25 && (
          <div className="w-full p-2 bg-yellow-900 border border-yellow-500 rounded text-center">
            <p className="text-yellow-200 text-sm font-bold">CRITICALLY WOUNDED</p>
          </div>
        )}
      </div>
    </div>
  );
}